Replication files for "Do the Unemployed Pay Lower Prices? A Reassessment of the Value of Unemployment Insurance", JEEA, by Rodolfo G. Campos and Iliana Reggio
April 30, 2019.


GENERAL INSTRUCTIONS:

Necessary preliminary steps before running this dofile:
1) Download data from INE: https://www.ine.es/;  EPF: Encuesta de Presupuestos Familiares. Base 2006; period 2006-2014; save the file COICOP_HBS_2006.dta in the same folder. 
We assume the user has three files: one with expenditure data, one with household data, and one with members' data.

2) Run 1_price_index.do: it constructs the dataset priceindex.dta that contains the price indices used in the paper. It needs expenditure data.

3) Run 2_prepare_dataset: it merges all the files: expenditures, households, and members. 
Then, it creates all the variables needed and saves a single dataset: data_ine.dta

4) Run 3_results: it replicates Table 1 to Table 10 in the paper.

Data and do-files are compatible with Stata 13.
